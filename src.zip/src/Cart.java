class Cart {

    Node top = null;

    void push(Product p) {
        Node newNode = new Node(p);
        newNode.next = top;
        top = newNode;

        System.out.println(p.name + " added to cart.");
    }

    void pop() {
        if (top == null) {
            System.out.println("Cart is empty");
            return;
        }

        System.out.println("Removed from cart: " + top.product.name);
        top = top.next;
    }

    void displayCart() {
        if (top == null) {
            System.out.println("Cart is empty");
            return;
        }

        Node temp = top;
        System.out.println("\nCart Items (FILO):");

        while (temp != null) {
            System.out.println(temp.product.id + " " + temp.product.name + " Rs." + temp.product.price);
            temp = temp.next;
        }
    }
}