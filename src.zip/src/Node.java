class Node {
    Product product;
    Node next;

    Node(Product product) {
        this.product = product;
        this.next = null;
    }
}