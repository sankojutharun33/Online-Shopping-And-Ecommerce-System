import java.util.HashMap;

class ProductHash {

    HashMap<Integer, Product> map = new HashMap<>();

    void addProducts(Product products[]) {
        for (Product p : products) {
            map.put(p.id, p);
        }
    }

    Product search(int id) {
        return map.get(id);
    }
}