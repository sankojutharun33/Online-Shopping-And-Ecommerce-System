class DeliveryQueue {

    int front = -1, rear = -1;
    int size = 5;
    Product queue[] = new Product[size];

    void addForDelivery(Product p) {

        if ((rear + 1) % size == front) {
            System.out.println("Delivery Queue Full");
            return;
        }

        if (front == -1)
            front = 0;

        rear = (rear + 1) % size;
        queue[rear] = p;

        System.out.println(p.name + " added for delivery.");
    }

    void deliverProduct() {

        if (front == -1) {
            System.out.println("No deliveries pending");
            return;
        }

        System.out.println("Delivered: " + queue[front].name);

        if (front == rear)
            front = rear = -1;
        else
            front = (front + 1) % size;
    }
}