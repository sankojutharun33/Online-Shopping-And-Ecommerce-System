class OrderQueue {

    int front = -1, rear = -1;
    int size = 5;
    Product queue[] = new Product[size];

    void enqueue(Product p) {

        if ((rear + 1) % size == front) {
            System.out.println("Order Queue Full");
            return;
        }

        if (front == -1)
            front = 0;

        rear = (rear + 1) % size;
        queue[rear] = p;

        System.out.println(p.name + " order placed.");
    }

    Product dequeue() {

        if (front == -1) {
            System.out.println("No orders to process");
            return null;
        }

        Product temp = queue[front];
        System.out.println("Processing order: " + temp.name);

        if (front == rear)
            front = rear = -1;
        else
            front = (front + 1) % size;

        return temp;
    }

    void displayOrders() {

        if (front == -1) {
            System.out.println("No orders in queue");
            return;
        }

        System.out.println("\nOrders in Queue:");

        int i = front;
        while (true) {
            System.out.println(queue[i].id + " " + queue[i].name + " Rs." + queue[i].price);
            if (i == rear)
                break;
            i = (i + 1) % size;
        }
    }
}