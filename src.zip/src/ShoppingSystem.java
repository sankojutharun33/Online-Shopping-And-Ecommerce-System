import java.util.Scanner;

public class ShoppingSystem {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Product products[] = {
            new Product(101, "Laptop", 55000),
            new Product(102, "Phone", 20000),
            new Product(103, "Headphones", 3000),
            new Product(104, "Keyboard", 1500),
            new Product(105, "Mouse", 700),
            new Product(106, "Charger", 7000),
            new Product(107, "Washing Machine", 13000),
            new Product(108, "Table Fan", 3200),
            new Product(109, "Cycle", 10000),
            new Product(110, "Watch", 4000),
            new Product(111, "TV", 70000)
        };

        Cart cart = new Cart();
        OrderQueue orderQueue = new OrderQueue();
        DeliveryQueue deliveryQueue = new DeliveryQueue();

        ProductHash hash = new ProductHash();
        hash.addProducts(products);

        int choice;

        do {
            System.out.println("\n===== ONLINE SHOPPING SYSTEM =====");
            System.out.println("1. View Products");
            System.out.println("2. Search Product");
            System.out.println("3. Add to Cart");
            System.out.println("4. Remove from Cart");
            System.out.println("5. View Cart");
            System.out.println("6. Place Order");
            System.out.println("7. Process Order");
            System.out.println("8. View Orders");
            System.out.println("9. Deliver Product");
            System.out.println("10. Exit");

            System.out.print("Enter choice: ");
            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    ProductService.displayProducts(products);
                    break;

                case 2:
                    System.out.print("Enter Product ID: ");
                    int id = sc.nextInt();

                    Product result = hash.search(id);
                    if (result != null)
                        System.out.println("Found: " + result.name + " Rs." + result.price);
                    else
                        System.out.println("Product not found");
                    break;

                case 3:
                    System.out.print("Enter Product ID: ");
                    int cartId = sc.nextInt();

                    Product p1 = hash.search(cartId);
                    if (p1 != null)
                        cart.push(p1);
                    else
                        System.out.println("Product not found");
                    break;

                case 4:
                    cart.pop();
                    break;

                case 5:
                    cart.displayCart();
                    break;

                case 6:
                    System.out.print("Enter Product ID: ");
                    int orderId = sc.nextInt();

                    Product p2 = hash.search(orderId);
                    if (p2 != null)
                        orderQueue.enqueue(p2);
                    else
                        System.out.println("Product not found");
                    break;

                case 7:
                    Product processed = orderQueue.dequeue();
                    if (processed != null)
                        deliveryQueue.addForDelivery(processed);
                    break;

                case 8:
                    orderQueue.displayOrders();
                    break;

                case 9:
                    deliveryQueue.deliverProduct();
                    break;

                case 10:
                    System.out.println("Thank you for shopping!");
                    break;

                default:
                    System.out.println("Invalid choice");
            }

        } while (choice != 10);

        sc.close();
    }
}