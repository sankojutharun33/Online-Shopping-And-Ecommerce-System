class ProductService {

    static void displayProducts(Product products[]) {
        System.out.println("\nProduct List:");
        for (Product p : products) {
            System.out.println(p.id + " " + p.name + " Rs." + p.price);
        }
    }
}